/*
-- Query: SELECT * FROM MyDB.librarians
LIMIT 0, 1000

-- Date: 2022-06-06 21:23
*/
INSERT INTO `` (`libname`,`id`,`libpassword`,`username`) VALUES ('Salma',1,'pass','salmaahmed');
INSERT INTO `` (`libname`,`id`,`libpassword`,`username`) VALUES ('Ahmed Ali',11110,'1212121','AhmedAli22');
INSERT INTO `` (`libname`,`id`,`libpassword`,`username`) VALUES ('Ziyad Ahmed',11111,'pass111','ziyadahmed3');
INSERT INTO `` (`libname`,`id`,`libpassword`,`username`) VALUES ('Muhammed Reda',11112,'Mreda','pass2131');
