/*
-- Query: SELECT * FROM MyDB.admins
LIMIT 0, 1000

-- Date: 2022-06-06 21:23
*/
INSERT INTO `` (`idadmins`,`adminsname`,`admins_username`,`admins_password`,`admins_email`) VALUES (33221,'Ahmed Ashraf','AhmAsh','tretre','Ashraf@ymail.com');
INSERT INTO `` (`idadmins`,`adminsname`,`admins_username`,`admins_password`,`admins_email`) VALUES (33222,'Ziyad Akram','ZiyadAk','pass166','zakram@ymail.com');
