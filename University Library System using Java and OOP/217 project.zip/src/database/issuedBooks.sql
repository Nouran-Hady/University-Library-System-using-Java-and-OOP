/*
-- Query: SELECT * FROM MyDB.issuedBooks
LIMIT 0, 1000

-- Date: 2022-06-06 21:23
*/
