/*
-- Query: SELECT * FROM MyDB.members
LIMIT 0, 1000

-- Date: 2022-06-06 21:22
*/
INSERT INTO `` (`idmembers`,`mem_name`,`mem_username`,`mem_password`) VALUES (20200,'Salma Ahmed','SalmaAhmed','passs');
INSERT INTO `` (`idmembers`,`mem_name`,`mem_username`,`mem_password`) VALUES (20201,'Yara Ali','YaraAlii','21yaraa');
INSERT INTO `` (`idmembers`,`mem_name`,`mem_username`,`mem_password`) VALUES (20202,'Yaser Muhammed','YasM','tripleee');
