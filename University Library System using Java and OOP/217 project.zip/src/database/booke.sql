/*
-- Query: SELECT * FROM MyDB.books
LIMIT 0, 1000

-- Date: 2022-06-06 21:22
*/
INSERT INTO `` (`isbn`,`bookname`,`author_name`,`genre`,`issued_amount`,`available_amount`) VALUES (110,'Harry Potter and Philospher Stone','JK Rowling','Fantasy',12,100);
INSERT INTO `` (`isbn`,`bookname`,`author_name`,`genre`,`issued_amount`,`available_amount`) VALUES (111,'Cinder','Marissa Mayer','Fantasy',10,90);
INSERT INTO `` (`isbn`,`bookname`,`author_name`,`genre`,`issued_amount`,`available_amount`) VALUES (112,'Oliver Twist','Charles Dickens','Fantasy',3,50);
