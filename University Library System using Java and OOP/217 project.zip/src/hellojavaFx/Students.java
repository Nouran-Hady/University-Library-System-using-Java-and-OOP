/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nouran Hady Shaaban
 * 
 * Student ID	Student name	Student Birthday	Email       Mobile number
 */
package hellojavaFx;


import java.util.*;

import com.opencsv.CSVWriter;

import java.io.*;
import java.lang.String;


public class Students {
    private String ID;    
    private String name;
    private String Birthday;
    private String Email;
    private String Mobile_number;

    public int File_write(ArrayList <String> list) throws IOException{

        try{     
    File fr = new File("Students.csv");
    Scanner sc = new Scanner(fr);
    PrintWriter pr = new PrintWriter(new FileWriter(fr,true));
//    FileWriter fr = new FileWriter (f);
    CSVWriter writer = new CSVWriter  (pr);
    int i=0;
    int j=0;
    
    while(sc.hasNextLine()){
       String s = sc.nextLine();
       for (i=0; i <list.size() ;i++) {
    	   if (s.contains(list.get(i)) && i != 2){
           return 1;
       }
       }
 
    }
    String[] myArray = new String[list.size()];
    list.toArray(myArray);
    
    writer.write(myArray);
     

    writer.close();
    pr.close();
    sc.close();
    }
    catch(FileNotFoundException e){
    System.out.println(e);
    }
     return 0;   
    }
    
    public static void clearTheFile() throws IOException{
        FileWriter fwOb = new FileWriter("C:\\nu 2021\\spring2022\\csci217\\assignment\\Students.csv", false); 
        PrintWriter pwOb = new PrintWriter(fwOb, false);
        pwOb.flush();
        pwOb.close();
        fwOb.close();
    }
    
    public String delete_object(String s1 ,String name) throws IOException{
        try{     
        File fr = new File("C:\\nu 2021\\spring2022\\csci217\\assignment\\Students.csv");
        Scanner sc = new Scanner(fr);
        
        ArrayList<String> line=new ArrayList<String>();
        int i=0;
        int flag=0;


        while(sc.hasNextLine()){
           String s = sc.nextLine();
           
           if (s.contains(s1)&&s.contains(name)){
               flag=1;
               continue;
           }
           else
               line.add(s);
  
        }
        
        PrintWriter pw = new PrintWriter(new FileWriter(fr));
        CSVWriter writer = new CSVWriter(pw);
        
        String[] m = new String[line.size()];
      
        while(i<line.size()){
        	m=line.get(i).split(",");
        	writer.writeNext(m);  	
            i++;
        }
        
        writer.close();
        sc.close();
    
        if (flag==1)
            return "###Student deleted###";
        else
            return "###Student not found###";
   
    }
    catch(FileNotFoundException e){
    System.out.println(e);
    }
    return " ";
  
    }
    
    public boolean check_student(String s1) throws IOException{
        try{     
        File fr = new File("C:\\nu 2021\\spring2022\\csci217\\assignment\\Students.csv");
        Scanner sc = new Scanner(fr);
        
        while(sc.hasNextLine()){
           String s = sc.nextLine();
           if (s.contains(s1))
               return true;
        }
        
        sc.close();
    }
    catch(FileNotFoundException e){
    System.out.println(e);
    }
    return false;
    }
    
}