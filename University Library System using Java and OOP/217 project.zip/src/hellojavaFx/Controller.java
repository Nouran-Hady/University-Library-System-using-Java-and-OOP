//package hellojavaFx;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.control.Label;
//
//public class Controller {
//	@FXML
//
//	public void LogninasAdmin(ActionEvent e) {
//		Librarians librarian = new Librarians();		
//		
//	}
//public void LogninasLibrarian(ActionEvent e) {
//		
//	Admins admin= new Admins();
//		
//	}
//}