
import java.io.IOException;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nouran Hady Shaaban
 */
public class LoginWindow {
    public void call_main()throws IOException{
        String[] args={""};
        LoginWindow.main(args);
    }
     public static void main (String[] args)throws IOException{
        AdminView Admin= new AdminView();
        LibrarianView librarian1= new LibrarianView();
        
        Scanner input = new Scanner(System.in); //to input a string 
        int choice=0;
        do{
        System.out.println("\n1- librarian \n2-Admin \n0-exit");
        choice = input.nextInt();
        switch (choice){
                case 1:
                    librarian1.login();
                    break;
                    
                case 2:
                    Admin.login();
                    break;
        }
        }while(choice!=0);
     }
    
}
