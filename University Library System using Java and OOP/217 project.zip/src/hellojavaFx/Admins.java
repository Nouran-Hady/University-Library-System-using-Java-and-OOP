package hellojavaFx;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import com.opencsv.CSVWriter;

public class Admins {
    private String ID;
    private String Admin_Name;
    private String Admin_Password;
    
    public int File_write(ArrayList <String> list) throws IOException{
        
        try{     
    File Admins = new File("C:\\Users\\101\\eclipse-workspace\\hellojavaFx--reference_fo_fx_functions\\src\\hellojavaFx\\Admins.csv");
    Scanner sc = new Scanner(Admins);
    PrintWriter pr = new PrintWriter(new FileWriter(Admins,true));
//  FileWriter pr = new FileWriter (fr);
  CSVWriter writer = new CSVWriter(pr);
  int i=0;
  int j=0;
  
while(sc.hasNextLine()){
     String s = sc.nextLine();
     for (i=0; i <list.size() ;i++) {
  	   if (s.contains(list.get(i)) && i != 2){
         return 1;
     }
     }

  }
  String[] myArray = new String[list.size()];
  list.toArray(myArray);
  
 writer.writeNext(myArray);
   

   
  writer.close();
  sc.close();
   
    }
    catch(FileNotFoundException e){
    System.out.println(e);
    }
    return 0;
  
    }
    
    public boolean check_login(String user_name, String password)throws IOException{
        try{     
        File fr = new File("C:\\nu 2021\\spring2022\\csci217\\assignment\\Admins.csv");
        Scanner sc = new Scanner(fr);
      
        while(sc.hasNextLine()){
           String s = sc.nextLine();
           
           if (s.contains(user_name) && s.contains(user_name) )
               return true;
        }
       sc.close();
    
    
        }
    catch(FileNotFoundException e){
    System.out.println(e);
    }
        
     return false;   
    }
    
    public String delete_object(String ID, String name) throws IOException{
        try{     
        File fr = new File("Admins.csv");
        Scanner sc = new Scanner(fr); 
        ArrayList<String> line=new ArrayList<String>();
        int i=0;
        int flag=0;


        while(sc.hasNextLine()){
           String s = sc.nextLine();
           
           if (s.contains(ID) && s.contains(name)){
               flag=1;
               continue;
           }
           else
               line.add(s);
  
        }
        
        PrintWriter pw = new PrintWriter(new FileWriter(fr));
       
        while(i<line.size()){
            pw.append(line.get(i));
            pw.append("\n");
            i++;
        }
        
        pw.close();
        sc.close();
    
        if (flag==1)
            return "\n###Admins deleted###\n";
        else
            return "\n###Admins not found###\n";
   
    }
    catch(FileNotFoundException e){
    System.out.println(e);
    }
    return " ";
  
    }

}
